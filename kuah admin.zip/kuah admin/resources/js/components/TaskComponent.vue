<template>
    <div class="container">
        <div class="row justify-content-center">
            <ul class="list-goup">
                <li class="list-group-item"> <a href = "#"> Tache 1 </a> </li>
                <li class="list-group-item"> <a href = "#"> Tache 2 </a> </li>
                <li class="list-group-item"> <a href = "#"> Tache 3 </a> </li>
                <li class="list-group-item"> <a href = "#"> Tache 4 </a> </li>
            </ul>
        </div>
    </div>
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
