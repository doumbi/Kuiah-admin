<template>
    
        
        <div class="layout-content-body">
          <div class="title-bar">
            <h1 class="title-bar-title">
              <span class="d-ib">Liste des publications</span>
               <router-link to="/ajoutpublication" class="btn btn-danger btn-sm btn-labeled" type="button" style="float: right;"><span class="btn-label">
                    <span class="icon icon-plus icon-lg icon-fw"></span>
                  </span>
                  Ajouter une publication
                </router-link>
            </h1>
          </div>
          <div class="row gutter-xs">
            <div class="col-md-3">
              <div class="card text-center">
                <div class="card-image">
                  <div class="overlay">
                    <div class="overlay-gradient">
                      <img class="card-img-top img-responsive" src="img/8335744038.jpg" alt="Instagram App">
                    </div>
                  </div>
                </div>
                <div class="card-avatar">
                </div>
                <div class="card-body">
                  <h3 class="card-title">Teddy Wilson</h3>
                  <h6 class="card-subtitle">CEO at Elephant</h6>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel harum....</p>
                  <div class="list-inline mb-4">
                    <span class="label arrow-right arrow-success" style="float: right;">100000 FCFA</span>
                    <span class="label arrow-left arrow-success" style="float: left;">100000 FCFA</span>
                  </div><br><br>
                  <ul class="list-inline mt-5">
                      <li>
                        <router-link to="/editpublication">
                            <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-edit icon-lg icon-fw"></span>
                          </button>
                        </router-link>
                      </li>
                      <li>
                        <a href="#">
                          <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-trash icon-lg icon-fw"></span>
                          </button>
                        </a>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card text-center">
                <div class="card-image">
                  <div class="overlay">
                    <div class="overlay-gradient">
                      <img class="card-img-top img-responsive" src="img/8335744038.jpg" alt="Instagram App">
                    </div>
                  </div>
                </div>
                <div class="card-avatar">
                </div>
                <div class="card-body">
                  <h3 class="card-title">Teddy Wilson</h3>
                  <h6 class="card-subtitle">CEO at Elephant</h6>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel harum....</p>
                  <div class="list-inline mb-4">
                    <span class="label arrow-right arrow-success" style="float: right;">100000 FCFA</span>
                    <span class="label arrow-left arrow-success" style="float: left;">100000 FCFA</span>
                  </div><br><br>
                  <ul class="list-inline mt-5">
                      <li>
                        <router-link to="/editpublication">
                            <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-edit icon-lg icon-fw"></span>
                          </button>
                        </router-link>
                      </li>
                      <li>
                        <a href="#">
                          <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-trash icon-lg icon-fw"></span>
                          </button>
                        </a>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
           <div class="col-md-3">
              <div class="card text-center">
                <div class="card-image">
                  <div class="overlay">
                    <div class="overlay-gradient">
                      <img class="card-img-top img-responsive" src="img/8335744038.jpg" alt="Instagram App">
                    </div>
                  </div>
                </div>
                <div class="card-avatar">
                </div>
                <div class="card-body">
                  <h3 class="card-title">Teddy Wilson</h3>
                  <h6 class="card-subtitle">CEO at Elephant</h6>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel harum....</p>
                  <div class="list-inline mb-4">
                    <span class="label arrow-right arrow-success" style="float: right;">100000 FCFA</span>
                    <span class="label arrow-left arrow-success" style="float: left;">100000 FCFA</span>
                  </div><br><br>
                  <ul class="list-inline mt-5">
                      <li>
                        <router-link to="/editpublication">
                            <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-edit icon-lg icon-fw"></span>
                          </button>
                        </router-link>
                      </li>
                      <li>
                        <a href="#">
                          <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-trash icon-lg icon-fw"></span>
                          </button>
                        </a>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card text-center">
                <div class="card-image">
                  <div class="overlay">
                    <div class="overlay-gradient">
                      <img class="card-img-top img-responsive" src="img/8335744038.jpg" alt="Instagram App">
                    </div>
                  </div>
                </div>
                <div class="card-avatar">
                </div>
                <div class="card-body">
                  <h3 class="card-title">Teddy Wilson</h3>
                  <h6 class="card-subtitle">CEO at Elephant</h6>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel harum....</p>
                  <div class="list-inline mb-4">
                    <span class="label arrow-right arrow-success" style="float: right;">100000 FCFA</span>
                    <span class="label arrow-left arrow-success" style="float: left;">100000 FCFA</span>
                  </div><br><br>
                  <ul class="list-inline mt-5">
                      <li>
                        <router-link to="/editpublication">
                            <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-edit icon-lg icon-fw"></span>
                          </button>
                        </router-link>
                      </li>
                      <li>
                        <a href="#">
                          <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-trash icon-lg icon-fw"></span>
                          </button>
                        </a>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
           <div class="col-md-3">
              <div class="card text-center">
                <div class="card-image">
                  <div class="overlay">
                    <div class="overlay-gradient">
                      <img class="card-img-top img-responsive" src="img/8335744038.jpg" alt="Instagram App">
                    </div>
                  </div>
                </div>
                <div class="card-avatar">
                </div>
                <div class="card-body">
                  <h3 class="card-title">Teddy Wilson</h3>
                  <h6 class="card-subtitle">CEO at Elephant</h6>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel harum....</p>
                  <div class="list-inline mb-4">
                    <span class="label arrow-right arrow-success" style="float: right;">100000 FCFA</span>
                    <span class="label arrow-left arrow-success" style="float: left;">100000 FCFA</span>
                  </div><br><br>
                  <ul class="list-inline mt-5">
                      <li>
                        <router-link to="/editpublication">
                            <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-edit icon-lg icon-fw"></span>
                          </button>
                        </router-link>
                      </li>
                      <li>
                        <a href="#">
                          <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-trash icon-lg icon-fw"></span>
                          </button>
                        </a>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card text-center">
                <div class="card-image">
                  <div class="overlay">
                    <div class="overlay-gradient">
                      <img class="card-img-top img-responsive" src="img/8335744038.jpg" alt="Instagram App">
                    </div>
                  </div>
                </div>
                <div class="card-avatar">
                </div>
                <div class="card-body">
                  <h3 class="card-title">Teddy Wilson</h3>
                  <h6 class="card-subtitle">CEO at Elephant</h6>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel harum....</p>
                  <div class="list-inline mb-4">
                    <span class="label arrow-right arrow-success" style="float: right;">100000 FCFA</span>
                    <span class="label arrow-left arrow-success" style="float: left;">100000 FCFA</span>
                  </div><br><br>
                  <ul class="list-inline mt-5">
                      <li>
                        <router-link to="/editpublication">
                            <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-edit icon-lg icon-fw"></span>
                          </button>
                        </router-link>
                      </li>
                      <li>
                        <a href="#">
                          <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-trash icon-lg icon-fw"></span>
                          </button>
                        </a>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
           <div class="col-md-3">
              <div class="card text-center">
                <div class="card-image">
                  <div class="overlay">
                    <div class="overlay-gradient">
                      <img class="card-img-top img-responsive" src="img/8335744038.jpg" alt="Instagram App">
                    </div>
                  </div>
                </div>
                <div class="card-avatar">
                </div>
                <div class="card-body">
                  <h3 class="card-title">Teddy Wilson</h3>
                  <h6 class="card-subtitle">CEO at Elephant</h6>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel harum....</p>
                  <div class="list-inline mb-4">
                    <span class="label arrow-right arrow-success" style="float: right;">100000 FCFA</span>
                    <span class="label arrow-left arrow-success" style="float: left;">100000 FCFA</span>
                  </div><br><br>
                  <ul class="list-inline mt-5">
                      <li>
                        <router-link to="/editpublication">
                            <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-edit icon-lg icon-fw"></span>
                          </button>
                        </router-link>
                      </li>
                      <li>
                        <a href="#">
                          <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-trash icon-lg icon-fw"></span>
                          </button>
                        </a>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card text-center">
                <div class="card-image">
                  <div class="overlay">
                    <div class="overlay-gradient">
                      <img class="card-img-top img-responsive" src="img/8335744038.jpg" alt="Instagram App">
                    </div>
                  </div>
                </div>
                <div class="card-avatar">
                </div>
                <div class="card-body">
                  <h3 class="card-title">Teddy Wilson</h3>
                  <h6 class="card-subtitle">CEO at Elephant</h6>
                  <p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vel harum....</p>
                  <div class="list-inline mb-4">
                    <span class="label arrow-right arrow-success" style="float: right;">100000 FCFA</span>
                    <span class="label arrow-left arrow-success" style="float: left;">100000 FCFA</span>
                  </div><br><br>
                  <ul class="list-inline mt-5">
                      <li>
                        <router-link to="/editpublication">
                            <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-edit icon-lg icon-fw"></span>
                          </button>
                        </router-link>
                      </li>
                      <li>
                        <a href="#">
                          <button class="btn btn-danger btn-sm btn-labeled" type="button">
                            <span class="icon icon-trash icon-lg icon-fw"></span>
                          </button>
                        </a>
                      </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
       </div>
       
   
</template>

<script>
    export default {
        mounted() {
            console.log('Component mounted.')
        }
    }
</script>
