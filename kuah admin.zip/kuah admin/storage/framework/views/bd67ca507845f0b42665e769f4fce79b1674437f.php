<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Laravel</title>   
        <link rel="stylesheet" href=" <?php echo e(asset('/css/vendor.min.css')); ?>">
        <link rel="stylesheet" href=" <?php echo e(asset('/css/elephant.min.css')); ?>">
        <link rel="stylesheet" href=" <?php echo e(asset('/css/application.min.css')); ?>">    
    </head>
    <body>
        <div id="app">
        <div class="layout layout-header-fixed">
                    <?php echo $__env->make('share.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="layout-main">
                    <?php echo $__env->make('share.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <div>
                        <div class="layout-content">
                        <router-view></router-view>
                        </div>
                    </div> 
                </div>
                    <?php echo $__env->make('share.theme', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/vendor.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/elephant.min.js')); ?>"></script>
      <script src="<?php echo e(asset('/js/application.min.js')); ?>"></script>
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','../../../www.google-analytics.com/analytics.js','ga');
      ga('create', 'UA-83990101-1', 'auto');
      ga('send', 'pageview');
    </script>
    </body>
</html>
<?php /**PATH /Users/doumbia/Desktop/kuah admin/resources/views/welcome.blade.php ENDPATH**/ ?>